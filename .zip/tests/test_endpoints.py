"""
Basic smoke tests for every endpoint.
Run with:  pytest tests/ -v

Note: face-recognition and product-classification tests only assert the
endpoint responds sensibly (200 with a message, or 503 if that model isn't
loaded on this machine) — they don't assert exact predictions, since those
depend on your trained model files.
"""
import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from app.main import app


@pytest.fixture(scope="module")
def client():
    # Using TestClient as a context manager triggers FastAPI's startup event
    # (db.init_db(), model status logging) before any requests are made.
    with TestClient(app) as c:
        yield c


def _dummy_image_bytes():
    img = Image.new("RGB", (224, 224), color=(120, 120, 200))
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    buf.seek(0)
    return buf


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_dashboard_stats(client):
    resp = client.get("/dashboard/stats")
    assert resp.status_code == 200
    body = resp.json()
    assert "models_loaded" in body
    assert "total_visits" in body


def test_analyze_sentiment(client):
    resp = client.post("/analyze-sentiment", json={"text": "I absolutely love this product!"})
    assert resp.status_code in (200, 503)
    if resp.status_code == 200:
        body = resp.json()
        assert body["label"] in ("Positive", "Negative", "Neutral")
        assert 0.0 <= body["confidence"] <= 1.0


def test_analyze_sentiment_validation(client):
    resp = client.post("/analyze-sentiment", json={"text": ""})
    assert resp.status_code == 422  # min_length=1 violated


def test_chatbot_rule_based(client):
    resp = client.post("/chatbot", json={"message": "what is your return policy?"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["source"] in ("rule", "ml", "fallback")
    assert isinstance(body["reply"], str) and len(body["reply"]) > 0


def test_chatbot_unknown_message(client):
    resp = client.post("/chatbot", json={"message": "asdkjhasdkjh random gibberish"})
    assert resp.status_code == 200
    assert "reply" in resp.json()


def test_classify_product(client):
    img_bytes = _dummy_image_bytes()
    resp = client.post(
        "/classify-product",
        files={"file": ("test.jpg", img_bytes, "image/jpeg")},
    )
    assert resp.status_code in (200, 503)
    if resp.status_code == 200:
        body = resp.json()
        assert "category" in body
        assert 0.0 <= body["confidence"] <= 1.0


def test_recognize_face(client):
    img_bytes = _dummy_image_bytes()
    resp = client.post(
        "/recognize-face",
        files={"file": ("test.jpg", img_bytes, "image/jpeg")},
    )
    assert resp.status_code in (200, 503)
    if resp.status_code == 200:
        body = resp.json()
        assert "recognized" in body


def test_unsupported_file_type_rejected(client):
    fake_file = io.BytesIO(b"not an image")
    resp = client.post(
        "/classify-product",
        files={"file": ("test.txt", fake_file, "text/plain")},
    )
    assert resp.status_code == 400
