# Smart Retail & Customer Intelligence Platform — Module C

Unified ML Pipeline & Deployment layer for the project. Wraps the Module A (CV)
and Module B (NLP/chatbot) models behind a single FastAPI gateway.

## What's in here

```
app/
  main.py              # FastAPI entrypoint, /dashboard/stats, /health
  auth.py              # X-API-Key header auth (C4)
  db.py                # SQLite storage: visits, reviews, chat_logs, classifications
  schemas.py           # Pydantic request/response models
  routers/
    vision.py          # /recognize-face, /classify-product
    nlp.py              # /analyze-sentiment
    chatbot.py          # /chatbot
  services/
    cv_service.py       # loads face_db.pkl + product_classifier.h5 once at startup
    nlp_service.py       # text cleaning + sentiment_model.pkl / vectorizer.pkl
    chatbot_service.py   # rule-based (intents.json) + ML fallback (chatbot_model.pkl)
  models/               # <- put your trained model files here (see below)
data/
  intents.json          # sample chatbot intents — replace with your own 20-30
tests/
  test_endpoints.py     # pytest smoke tests for every endpoint
notebooks/
  04_run_api_in_colab.ipynb   # mounts Drive, wires models, runs API live via ngrok
Dockerfile
requirements.txt
.github/workflows/deploy.yml   # CI: lint + test + build image on push
```

## 1. Drop your trained models into `app/models/`

| File                     | Produced by | Loader                          |
|--------------------------|-------------|----------------------------------|
| `product_classifier.h5`  | A2          | `tensorflow.keras.models.load_model` |
| `face_db.pkl`            | A3          | `pickle` — dict `{customer_id: encoding}` |
| `sentiment_model.pkl`    | B2          | `joblib` (sklearn Pipeline or bare classifier) |
| `vectorizer.pkl`         | B2          | `joblib` — only needed if `sentiment_model.pkl` is a bare classifier, not a full Pipeline |
| `chatbot_model.pkl`      | B3          | `joblib` — TF-IDF + classifier trained on `data/intents.json` |
| `product_labels.json`    | optional    | list of class names in the order your model outputs them |

**Every model is optional at boot** — if a file is missing, its endpoint returns
`503` with a clear message instead of crashing the whole API, so you can bring
models online incrementally.

## 2. Run locally / in Docker

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
# Swagger UI: http://localhost:8000/docs
```

```bash
docker build -t smart-retail-ai .
docker run -p 8000:8000 -v $(pwd)/app/models:/code/app/models smart-retail-ai
```

## 3. Run live from Google Colab

Open `notebooks/04_run_api_in_colab.ipynb` in Colab. It will:
1. Mount your Drive.
2. Copy your trained model files into `app/models/`.
3. Install dependencies.
4. Start the API and tunnel it publicly via `ngrok` (or `localtunnel`), giving you
   a public URL + working `/docs` Swagger page you can hit from Postman on your phone/laptop.

You'll need to:
- Upload `smart-retail-ai.zip` (this whole folder) to the Colab session, **or** keep the code in Drive.
- Set `DRIVE_PROJECT_FOLDER` in the notebook to wherever your models/intents.json live in Drive.
- Get a free ngrok authtoken from https://dashboard.ngrok.com if using the ngrok option.

## 4. Simulated production auth

Set the `API_KEY` environment variable (or the Colab cell's `os.environ['API_KEY']`)
to require callers to send an `X-API-Key` header. Leave it unset to disable auth
for easier local testing.

## 5. Testing

```bash
pytest tests/ -v
```

## 6. Deploying beyond Colab

Push this repo to GitHub — `.github/workflows/deploy.yml` will lint, test, and
build the Docker image on every push. From there, point Render/Railway/Cloud Run
at the repo (or the built image) — all three support Dockerfile-based deploys
with a free tier.
